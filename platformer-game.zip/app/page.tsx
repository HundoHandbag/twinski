"use client"

import { useEffect, useRef, useState } from "react"

interface Player {
  x: number
  y: number
  width: number
  height: number
  velocityX: number
  velocityY: number
  onGround: boolean
}

interface Platform {
  x: number
  y: number
  width: number
  height: number
}

interface Collectible {
  x: number
  y: number
  width: number
  height: number
  collected: boolean
}

export default function PlatformerGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [score, setScore] = useState(0)
  const [gameOver, setGameOver] = useState(false)
  const [gameWon, setGameWon] = useState(false)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    // Game constants
    const GRAVITY = 0.5
    const JUMP_FORCE = -12
    const MOVE_SPEED = 5
    const CANVAS_WIDTH = 800
    const CANVAS_HEIGHT = 600

    // Set canvas size
    canvas.width = CANVAS_WIDTH
    canvas.height = CANVAS_HEIGHT

    // Player
    const player: Player = {
      x: 50,
      y: 400,
      width: 30,
      height: 40,
      velocityX: 0,
      velocityY: 0,
      onGround: false,
    }

    const platforms: Platform[] = [
      { x: 0, y: 550, width: 200, height: 50 }, // Starting rooftop
      { x: 250, y: 450, width: 100, height: 20 }, // Fire escape
      { x: 400, y: 350, width: 120, height: 20 }, // Building ledge
      { x: 150, y: 300, width: 80, height: 20 }, // Window sill
      { x: 300, y: 200, width: 100, height: 20 }, // Another rooftop
      { x: 500, y: 250, width: 150, height: 20 }, // Long building top
      { x: 650, y: 150, width: 100, height: 20 }, // High rise ledge
      { x: 700, y: 50, width: 100, height: 20 }, // Parents' apartment balcony
    ]

    const collectibles: Collectible[] = [
      { x: 280, y: 420, width: 15, height: 15, collected: false }, // Sneaker
      { x: 450, y: 320, width: 15, height: 15, collected: false }, // Basketball
      { x: 180, y: 270, width: 15, height: 15, collected: false }, // Chain
      { x: 340, y: 170, width: 15, height: 15, collected: false }, // Cap
      { x: 550, y: 220, width: 15, height: 15, collected: false }, // Phone
      { x: 680, y: 120, width: 15, height: 15, collected: false }, // Keys
      { x: 730, y: 20, width: 15, height: 15, collected: false }, // Love letter
    ]

    // Input handling
    const keys: { [key: string]: boolean } = {}

    const handleKeyDown = (e: KeyboardEvent) => {
      keys[e.key.toLowerCase()] = true
    }

    const handleKeyUp = (e: KeyboardEvent) => {
      keys[e.key.toLowerCase()] = false
    }

    document.addEventListener("keydown", handleKeyDown)
    document.addEventListener("keyup", handleKeyUp)

    // Collision detection
    const checkCollision = (rect1: any, rect2: any) => {
      return (
        rect1.x < rect2.x + rect2.width &&
        rect1.x + rect1.width > rect2.x &&
        rect1.y < rect2.y + rect2.height &&
        rect1.y + rect1.height > rect2.y
      )
    }

    // Game loop
    const gameLoop = () => {
      if (gameOver || gameWon) return

      // Clear canvas
      ctx.fillStyle = "#ffffff"
      ctx.fillRect(0, 0, CANVAS_WIDTH, CANVAS_HEIGHT)

      // Handle input
      if (keys["a"] || keys["arrowleft"]) {
        player.velocityX = -MOVE_SPEED
      } else if (keys["d"] || keys["arrowright"]) {
        player.velocityX = MOVE_SPEED
      } else {
        player.velocityX = 0
      }

      if ((keys["w"] || keys["arrowup"] || keys[" "]) && player.onGround) {
        player.velocityY = JUMP_FORCE
        player.onGround = false
      }

      // Apply gravity
      player.velocityY += GRAVITY

      // Update player position
      player.x += player.velocityX
      player.y += player.velocityY

      // Platform collision
      player.onGround = false
      for (const platform of platforms) {
        if (checkCollision(player, platform)) {
          // Landing on top of platform
          if (player.velocityY > 0 && player.y < platform.y) {
            player.y = platform.y - player.height
            player.velocityY = 0
            player.onGround = true
          }
          // Hitting platform from below
          else if (player.velocityY < 0 && player.y > platform.y) {
            player.y = platform.y + platform.height
            player.velocityY = 0
          }
          // Side collisions
          else if (player.velocityX > 0) {
            player.x = platform.x - player.width
          } else if (player.velocityX < 0) {
            player.x = platform.x + platform.width
          }
        }
      }

      // Collectible collision
      for (const collectible of collectibles) {
        if (!collectible.collected && checkCollision(player, collectible)) {
          collectible.collected = true
          setScore((prev) => prev + 10)
        }
      }

      // Check win condition
      const allCollected = collectibles.every((c) => c.collected)
      if (allCollected && player.x > 700 && player.y < 100) {
        setGameWon(true)
        return
      }

      // Check game over (fall off screen)
      if (player.y > CANVAS_HEIGHT) {
        setGameOver(true)
        return
      }

      // Keep player in bounds horizontally
      if (player.x < 0) player.x = 0
      if (player.x + player.width > CANVAS_WIDTH) player.x = CANVAS_WIDTH - player.width

      // Draw everything with sketch style
      ctx.strokeStyle = "#000000"
      ctx.fillStyle = "#000000"
      ctx.lineWidth = 2

      for (const platform of platforms) {
        ctx.beginPath()
        // Add slight randomness for sketch effect
        const jitter = () => (Math.random() - 0.5) * 2
        ctx.moveTo(platform.x + jitter(), platform.y + jitter())
        ctx.lineTo(platform.x + platform.width + jitter(), platform.y + jitter())
        ctx.lineTo(platform.x + platform.width + jitter(), platform.y + platform.height + jitter())
        ctx.lineTo(platform.x + jitter(), platform.y + platform.height + jitter())
        ctx.closePath()
        ctx.stroke()

        // Add brick pattern for building texture
        for (let i = 0; i < platform.width; i += 15) {
          for (let j = 0; j < platform.height; j += 8) {
            ctx.strokeRect(platform.x + i, platform.y + j, 15, 8)
          }
        }
      }

      ctx.beginPath()
      const jitter = () => (Math.random() - 0.5) * 1
      // Body (hoodie)
      ctx.moveTo(player.x + jitter(), player.y + 10 + jitter())
      ctx.lineTo(player.x + player.width + jitter(), player.y + 10 + jitter())
      ctx.lineTo(player.x + player.width + jitter(), player.y + player.height + jitter())
      ctx.lineTo(player.x + jitter(), player.y + player.height + jitter())
      ctx.closePath()
      ctx.stroke()

      // Hood
      ctx.beginPath()
      ctx.arc(player.x + player.width / 2, player.y + 8, 12, Math.PI, 0)
      ctx.stroke()

      // Face under hood
      ctx.fillRect(player.x + 8, player.y + 8, 3, 3) // Left eye
      ctx.fillRect(player.x + 18, player.y + 8, 3, 3) // Right eye
      ctx.fillRect(player.x + 10, player.y + 15, 10, 2) // Mouth

      // Sneakers
      ctx.fillRect(player.x + 2, player.y + player.height - 5, 12, 5)
      ctx.fillRect(player.x + 16, player.y + player.height - 5, 12, 5)

      const collectibleTypes = ["👟", "🏀", "⛓️", "🧢", "📱", "🔑", "💌"]
      for (let i = 0; i < collectibles.length; i++) {
        const collectible = collectibles[i]
        if (!collectible.collected) {
          ctx.beginPath()
          ctx.arc(
            collectible.x + collectible.width / 2,
            collectible.y + collectible.height / 2,
            collectible.width / 2,
            0,
            Math.PI * 2,
          )
          ctx.stroke()

          // Different patterns for different items
          ctx.beginPath()
          if (i === 0) {
            // Sneaker - shoe lace pattern
            ctx.moveTo(collectible.x + 3, collectible.y + 5)
            ctx.lineTo(collectible.x + 12, collectible.y + 5)
            ctx.moveTo(collectible.x + 3, collectible.y + 10)
            ctx.lineTo(collectible.x + 12, collectible.y + 10)
          } else if (i === 1) {
            // Basketball - lines
            ctx.moveTo(collectible.x, collectible.y + 7)
            ctx.lineTo(collectible.x + 15, collectible.y + 7)
            ctx.moveTo(collectible.x + 7, collectible.y)
            ctx.lineTo(collectible.x + 7, collectible.y + 15)
          } else if (i === 2) {
            // Chain - links
            for (let j = 0; j < 3; j++) {
              ctx.arc(collectible.x + 5 + j * 3, collectible.y + 7, 2, 0, Math.PI * 2)
            }
          } else if (i === 3) {
            // Cap - visor
            ctx.moveTo(collectible.x + 3, collectible.y + 7)
            ctx.lineTo(collectible.x + 12, collectible.y + 7)
            ctx.lineTo(collectible.x + 15, collectible.y + 10)
          } else if (i === 4) {
            // Phone - screen
            ctx.rect(collectible.x + 4, collectible.y + 3, 7, 9)
          } else if (i === 5) {
            // Keys - key shape
            ctx.rect(collectible.x + 5, collectible.y + 5, 3, 8)
            ctx.rect(collectible.x + 8, collectible.y + 8, 4, 2)
          } else {
            // Love letter - heart
            ctx.moveTo(collectible.x + 7, collectible.y + 5)
            ctx.lineTo(collectible.x + 5, collectible.y + 3)
            ctx.lineTo(collectible.x + 7, collectible.y + 7)
            ctx.lineTo(collectible.x + 9, collectible.y + 3)
            ctx.lineTo(collectible.x + 7, collectible.y + 5)
          }
          ctx.stroke()
        }
      }

      ctx.font = "16px monospace"
      ctx.fillText("Chase down Jack Houser on the rooftops!", 10, 30)
      ctx.fillText("Collect your gear and confront him!", 10, 50)

      requestAnimationFrame(gameLoop)
    }

    gameLoop()

    return () => {
      document.removeEventListener("keydown", handleKeyDown)
      document.removeEventListener("keyup", handleKeyUp)
    }
  }, [gameOver, gameWon])

  const resetGame = () => {
    setScore(0)
    setGameOver(false)
    setGameWon(false)
  }

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-800 p-4">
      <div className="mb-4 text-center">
        <h1 className="text-4xl font-bold mb-2 text-white font-mono">Chase Parents Adventure Land</h1>
        <p className="text-xl text-gray-300">Score: {score}</p>
        <p className="text-sm text-gray-400 mt-1">Urban Parkour Challenge</p>
      </div>

      <div className="relative">
        <canvas
          ref={canvasRef}
          className="border-2 border-gray-600 bg-white shadow-lg"
          style={{ imageRendering: "pixelated" }}
        />

        {gameOver && (
          <div className="absolute inset-0 bg-black bg-opacity-75 flex items-center justify-center">
            <div className="bg-gray-900 text-white p-6 rounded-lg text-center border border-gray-600">
              <h2 className="text-2xl font-bold mb-4">Yo, You Fell!</h2>
              <p className="mb-4">The streets got you this time...</p>
              <button
                onClick={resetGame}
                className="px-6 py-2 bg-red-600 text-white rounded hover:bg-red-700 font-bold"
              >
                Run It Back
              </button>
            </div>
          </div>
        )}

        {gameWon && (
          <div className="absolute inset-0 bg-black bg-opacity-75 flex items-center justify-center">
            <div className="bg-gray-900 text-white p-6 rounded-lg text-center border border-gray-600">
              <h2 className="text-2xl font-bold mb-4">You Beat Jack Houser! 💪</h2>
              <p className="mb-2">That fool got what he deserved!</p>
              <p className="mb-4">Final Score: {score}</p>
              <button
                onClick={resetGame}
                className="px-6 py-2 bg-green-600 text-white rounded hover:bg-green-700 font-bold"
              >
                Run It Back
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="mt-4 text-center text-sm text-gray-400">
        <p className="font-mono">Controls: WASD or Arrow Keys to move, W/Up/Space to jump</p>
        <p className="font-mono">Mission: Collect all your gear and beat Jack Houser!</p>
        <p className="text-xs mt-2 text-gray-500">Navigate the urban jungle and settle the score</p>
      </div>
    </div>
  )
}
